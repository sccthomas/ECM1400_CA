test\_covid\_data\_handler module
=================================

.. automodule:: test_covid_data_handler
   :members:
   :undoc-members:
   :show-inheritance:
