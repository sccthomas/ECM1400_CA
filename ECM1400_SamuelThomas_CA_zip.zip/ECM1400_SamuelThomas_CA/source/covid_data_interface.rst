covid\_data\_interface module
=============================

.. automodule:: covid_data_interface
   :members:
   :undoc-members:
   :show-inheritance:
