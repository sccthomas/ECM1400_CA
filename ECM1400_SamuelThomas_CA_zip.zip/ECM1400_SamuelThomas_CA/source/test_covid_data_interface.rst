test\_covid\_data\_interface module
===================================

.. automodule:: test_covid_data_interface
   :members:
   :undoc-members:
   :show-inheritance:
