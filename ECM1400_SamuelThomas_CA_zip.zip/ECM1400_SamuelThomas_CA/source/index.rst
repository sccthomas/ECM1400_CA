.. ECM1400_CA_COVID19_DASHBOARD documentation master file, created by
   sphinx-quickstart on Mon Dec  6 16:31:33 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to ECM1400_CA_COVID19_DASHBOARD's documentation!
========================================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   readme
   modules
   

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
