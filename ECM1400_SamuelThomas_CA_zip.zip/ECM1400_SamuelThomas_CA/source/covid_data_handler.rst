covid\_data\_handler module
===========================

.. automodule:: covid_data_handler
   :members:
   :undoc-members:
   :show-inheritance:
